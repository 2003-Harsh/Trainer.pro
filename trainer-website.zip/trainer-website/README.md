Trainer Website (React + Express)
=================================

Modern trainer marketing site built with Vite + React + Tailwind on the frontend and a lightweight Node.js + Express backend.

## Highlights
- Hero, About, Programs, Video, Testimonials, and Contact sections with smooth scrolling, parallax accents, and motion.
- Tailwind CSS styling with AOS.js scroll animations and Framer Motion micro-interactions.
- Contact form posts to `/api/contact` and stores submissions in an in-memory list (swap in a database or email service when ready).
- Placeholder SVG images and sample MP4 video ready to swap for your branded assets.
- Production-ready Express server that can serve the Vite build.

## Project Structure
```
trainer-website/
├── frontend/         # Vite + React + Tailwind client
│   ├── public/       # Replaceable media assets
│   └── src/          # Components and styles
├── backend/          # Express API (no database dependency)
│   ├── routes/
│   └── server.js
└── README.md         # This file
```

## Quick Start
### Frontend
```bash
cd frontend
npm install
npm run dev        # start Vite dev server
npm run build      # build for production (outputs to dist/)
```

### Backend
```bash
cd backend
npm install
copy .env.example .env   # optional - adjust PORT if needed
npm run dev              # run with nodemon
```

### Run both locally
1. Start the backend on port 5000.
2. Start the frontend (defaults to http://localhost:5173).
3. During development you can set up a Vite proxy (see `vite.config.js`) or change the fetch URL in `frontend/src/components/Contact.jsx` to point at `http://localhost:5000/api/contact`.

## Media Placeholders
Replace the files in `frontend/public` with your own media while keeping file names or update component imports:
- `education-sample.mp4`
- `placeholder-hero.svg`
- `trainer-placeholder.svg`

## Build for deployment
1. `cd frontend && npm run build`
2. Copy the generated `frontend/dist` folder to the server.
3. Deploy the backend (`npm start`) with `NODE_ENV=production` so Express serves the static assets.
4. Set the `PORT` environment variable if you need something other than 5000.
