Assets in this folder can be replaced with your own media:
- education-sample.mp4          (hero background + gallery video)
- placeholder-hero.svg          (poster fallback for the hero section)
- trainer-placeholder.svg       (About section image)

Swap them with your branded visuals while keeping the same file names, or update the imports in the React components.
