import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'

const links = [
  { href: '#home', label: 'Home' },
  { href: '#about', label: 'About' },
  { href: '#programs', label: 'Programs' },
  { href: '#testimonials', label: 'Testimonials' },
  { href: '#contact', label: 'Contact' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className={`fixed inset-x-0 top-0 z-30 transition-all ${
        scrolled ? 'backdrop-blur-md bg-slate-950/70 shadow-lg' : 'bg-transparent'
      }`}
    >
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4 text-white">
        <a href="#home" className="text-lg font-bold tracking-wider">
          Trainer<span className="text-indigo-300">Pro</span>
        </a>
        <ul className="hidden items-center gap-8 text-sm font-semibold uppercase tracking-widest md:flex">
          {links.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="transition hover:text-indigo-200 focus:text-indigo-200 focus:outline-none"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>
        <a
          href="#contact"
          className="hidden rounded-full border border-white/60 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white transition hover:border-indigo-200 hover:text-indigo-200 sm:inline-flex"
        >
          Let&apos;s Talk
        </a>
      </nav>
    </motion.header>
  )
}

