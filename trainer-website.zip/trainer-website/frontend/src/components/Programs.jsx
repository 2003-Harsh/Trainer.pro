import React from 'react'
import { motion } from 'framer-motion'

const cards = [
  {
    title: 'Schools',
    desc: 'Teacher coaching, classroom innovation labs, student leadership bootcamps, and parent engagement workshops.',
    highlights: ['CBSE & IB aligned modules', 'STEM innovation sprints', 'Counsellor enablement'],
  },
  {
    title: 'Universities',
    desc: 'Future-of-work skills, research mentorship, startup incubation support, and faculty development series.',
    highlights: ['Career readiness intensives', 'Mentor certification', 'Industry immersion projects'],
  },
  {
    title: 'Corporates',
    desc: 'Leadership journeys, communication mastery, digital dexterity upskilling, and culture-building retreats.',
    highlights: ['Manager enablement labs', 'Design thinking workshops', 'DEI storytelling modules'],
  },
]

export default function Programs() {
  return (
    <section id="programs" className="bg-slate-50 py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="text-center" data-aos="fade-up">
          <p className="text-xs font-bold uppercase tracking-[0.4em] text-indigo-400">Programs</p>
          <h2 className="mt-3 text-3xl font-bold text-slate-900 md:text-4xl">
            Tailored learning pathways for every stage of growth
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-600">
            Whether you are building foundational skills or scaling advanced capabilities, each program is customised with
            diagnostics, immersive delivery, and measurable outcomes.
          </p>
        </div>

        <div className="mt-16 grid gap-8 md:grid-cols-3">
          {cards.map((card, index) => (
            <motion.article
              key={card.title}
              className="group relative overflow-hidden rounded-3xl bg-white p-8 shadow-lg transition duration-300 hover:-translate-y-3 hover:shadow-2xl"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ delay: index * 0.1 }}
            >
              <span className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 opacity-0 transition group-hover:opacity-100" />
              <h3 className="text-2xl font-semibold text-slate-900">{card.title}</h3>
              <p className="mt-4 text-slate-600">{card.desc}</p>
              <ul className="mt-6 space-y-3 text-sm font-semibold tracking-wide text-slate-500">
                {card.highlights.map((item) => (
                  <li key={item} className="flex items-center gap-3">
                    <span className="h-2.5 w-2.5 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500" />
                    {item}
                  </li>
                ))}
              </ul>
              <div className="mt-8">
                <a
                  href="#contact"
                  className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 px-6 py-3 text-sm font-bold uppercase tracking-wider text-white shadow-lg transition-all hover:from-indigo-400 hover:to-purple-500 hover:shadow-xl hover:-translate-y-1"
                >
                  Start a Conversation
                </a>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  )
}
