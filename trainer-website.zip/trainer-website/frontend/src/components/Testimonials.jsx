import React, { useEffect, useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

const testimonials = [
  {
    quote:
      'Our teachers loved the energy and practical frameworks. The post-workshop impact was visible in classrooms within a week.',
    name: 'Anita Rao',
    role: 'Principal, Maplewood High School',
    rating: 4.5,
  },
  {
    quote:
      'From ideation to final pitch, our students felt coached at every step. The program drove a 90% increase in project submissions.',
    name: 'Dr. Karthik Iyer',
    role: 'Dean of Innovation, Crestview University',
    rating: 5,
  },
  {
    quote:
      'The leadership labs were transformative. Teams now collaborate with empathy and clarity, and our NPS jumped significantly.',
    name: 'Meera Shah',
    role: 'AVP Learning & Development, Cobalt Technologies',
    rating: 4.5,
  },
]

const variants = {
  enter: { opacity: 0, x: 50 },
  center: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: -50 },
}

export default function Testimonials() {
  const [index, setIndex] = useState(0)
  const items = useMemo(() => testimonials, [])

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % items.length)
    }, 6000)
    return () => clearInterval(interval)
  }, [items.length])

  useEffect(() => {
    const handleVisibility = () => {
      const section = document.getElementById('testimonials')
      if (section && section.getBoundingClientRect().top < window.innerHeight / 2) {
        const evt = new Event('testimonialView')
        window.dispatchEvent(evt)
      }
    }
    window.addEventListener('scroll', handleVisibility, { passive: true })
    return () => window.removeEventListener('scroll', handleVisibility)
  }, [])

  return (
    <section id='testimonials' className='relative overflow-hidden bg-gradient-to-br from-indigo-50 via-white to-purple-50 py-24'>
      <div className='mx-auto max-w-4xl px-6 text-center'>
        <div data-aos='fade-up'>
          <p className='text-lg font-extrabold uppercase tracking-[0.2em] bg-gradient-to-r from-indigo-500 to-purple-600 bg-clip-text text-transparent'>Testimonials</p>
          <h2 className='mt-4 text-3xl font-bold text-slate-900 md:text-4xl'>What learning partners are saying</h2>
        </div>

        <div className='relative mt-16 min-h-[220px]'>
          <AnimatePresence mode='wait'>
            <motion.article
              key={items[index].name}
              variants={variants}
              initial='enter'
              animate='center'
              exit='exit'
              transition={{ duration: 0.5 }}
              className='mx-auto max-w-3xl rounded-3xl bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 p-1 shadow-2xl shadow-indigo-100'
            >
              <div className='rounded-3xl bg-white p-10'>
              <p className='text-xl font-medium text-slate-700 md:text-2xl'>"{items[index].quote}"</p>
              <div className='mt-8 text-left md:flex md:items-center md:justify-between'>
                <div>
                  <p className='text-lg font-semibold text-slate-900'>{items[index].name}</p>
                  <p className='text-sm uppercase tracking-widest text-slate-400'>{items[index].role}</p>
                </div>
                <div className='mt-6 flex flex-col items-center gap-4 md:mt-0 md:items-end'>
                  <div className='flex'>
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className={`text-yellow-400 ${i < Math.floor(items[index].rating) ? 'opacity-100' : i < items[index].rating ? 'opacity-50' : 'opacity-20'}`}>
                        ★
                      </span>
                    ))}
                  </div>
                  <div className='flex justify-center gap-2'>
                    {items.map((_, dotIndex) => (
                      <button
                        key={dotIndex}
                        type='button'
                        onClick={() => setIndex(dotIndex)}
                        className={`h-2.5 w-2.5 rounded-full transition ${
                          dotIndex === index ? 'bg-indigo-500 scale-110' : 'bg-slate-300 hover:bg-indigo-300'
                        }`}
                        aria-label={`Show testimonial ${dotIndex + 1}`}
                      />
                    ))}
                  </div>
                </div>
              </div>
              </div>
            </motion.article>
          </AnimatePresence>
        </div>
      </div>

      <div className='pointer-events-none absolute -left-20 top-8 h-60 w-60 rounded-full bg-indigo-200/40 blur-3xl' />
      <div className='pointer-events-none absolute -right-24 bottom-8 h-64 w-64 rounded-full bg-purple-200/40 blur-3xl' />
    </section>
  )
}

