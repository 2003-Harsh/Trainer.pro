import React, { useState } from 'react'
import { motion } from 'framer-motion'

const countryCodes = [
  { code: '+91', country: 'India', flag: '🇮🇳' },
  { code: '+1', country: 'USA', flag: '🇺🇸' },
  { code: '+44', country: 'UK', flag: '🇬🇧' },
  { code: '+61', country: 'Australia', flag: '🇦🇺' },
  { code: '+65', country: 'Singapore', flag: '🇸🇬' },
  { code: '+971', country: 'UAE', flag: '🇦🇪' },
  { code: '+49', country: 'Germany', flag: '🇩🇪' },
  { code: '+33', country: 'France', flag: '🇫🇷' },
]

export default function Contact() {
  const [status, setStatus] = useState({ state: 'idle', message: '' })

  const handleSubmit = async (event) => {
    event.preventDefault()
    setStatus({ state: 'loading', message: 'Sending your message...' })

    try {
      const formData = new FormData(event.target)
      formData.append('access_key', 'e838e0a0-3982-47be-9b6c-eda57a502a3a')
      
      // Combine country code and mobile number
      const countryCode = formData.get('countryCode')
      const mobile = formData.get('mobile')
      formData.set('mobile', `${countryCode} ${mobile}`)

      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        body: formData
      })

      const data = await response.json()

      if (data.success) {
        setStatus({ state: 'success', message: 'Thanks! I will get back to you soon.' })
        event.target.reset()
      } else {
        throw new Error('Failed to send message')
      }
    } catch (error) {
      setStatus({
        state: 'error',
        message: 'Something went wrong. Please try again.',
      })
    }
  }

  return (
    <section id="contact" className="bg-slate-900 py-24 text-white">
      <div className="mx-auto max-w-5xl px-6">
        <div className="text-center" data-aos="fade-up">
          <p className="text-lg font-extrabold uppercase tracking-[0.2em] text-teal-300">Connect</p>
          <h2 className="mt-4 text-3xl font-bold md:text-4xl">Let's design the next learning milestone together</h2>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-300">
            Share your context, and I'll craft an engagement that fits your goals - whether it's a single workshop or a
            multi-month transformation program.
          </p>
        </div>

        <div className="mt-12 grid gap-12 lg:grid-cols-2 lg:items-start">
          <motion.div
            className="flex justify-center"
            data-aos="fade-right"
          >
            <img
              src="/Contact .png"
              alt="Contact Us"
              className="max-w-sm w-full h-auto rounded-2xl"
            />
          </motion.div>

          <motion.form
            onSubmit={handleSubmit}
            className="grid gap-6 rounded-3xl border border-white/10 bg-white/10 p-8 shadow-2xl backdrop-blur"
            data-aos="fade-left"
          >
          <div className="grid gap-6 md:grid-cols-2">
            <label className="text-left text-sm font-semibold uppercase tracking-widest text-slate-200">
              Name
              <input
                type="text"
                name="name"
                required
                className="mt-2 w-full rounded-2xl border border-white/20 bg-white/10 px-4 py-3 text-base text-white placeholder:text-white/60 focus:border-indigo-300 focus:outline-none focus:ring-2 focus:ring-indigo-400/40"
                placeholder="Your full name"
              />
            </label>
            <label className="text-left text-sm font-semibold uppercase tracking-widest text-slate-200">
              Email
              <input
                type="email"
                name="email"
                required
                className="mt-2 w-full rounded-2xl border border-white/20 bg-white/10 px-4 py-3 text-base text-white placeholder:text-white/60 focus:border-indigo-300 focus:outline-none focus:ring-2 focus:ring-indigo-400/40"
                placeholder="you@gmail.com"
              />
            </label>
          </div>

          <label className="text-left text-sm font-semibold uppercase tracking-widest text-slate-200">
            Mobile Number
            <div className="mt-2 flex gap-2">
              <select
                name="countryCode"
                defaultValue="+91"
                required
                className="rounded-2xl border border-white/20 bg-white/10 px-3 py-3 text-base text-white focus:border-indigo-300 focus:outline-none focus:ring-2 focus:ring-indigo-400/40"
              >
                {countryCodes.map((country) => (
                  <option key={country.code} value={country.code} className="bg-slate-800 text-white">
                    {country.flag} {country.code}
                  </option>
                ))}
              </select>
              <input
                type="tel"
                name="mobile"
                required
                className="flex-1 rounded-2xl border border-white/20 bg-white/10 px-4 py-3 text-base text-white placeholder:text-white/60 focus:border-indigo-300 focus:outline-none focus:ring-2 focus:ring-indigo-400/40"
                placeholder="Your mobile number"
              />
            </div>
          </label>

          <label className="text-left text-sm font-semibold uppercase tracking-widest text-slate-200">
            Message
            <textarea
              name="message"
              rows={5}
              required
              className="mt-2 w-full rounded-2xl border border-white/20 bg-white/10 px-4 py-3 text-base text-white placeholder:text-white/60 focus:border-indigo-300 focus:outline-none focus:ring-2 focus:ring-indigo-400/40"
              placeholder="Tell me about your audience, goals, and timeline."
            />
          </label>

          <motion.button
            type="submit"
            whileTap={{ scale: 0.98 }}
            className="inline-flex items-center justify-center gap-3 rounded-full bg-gradient-to-r from-indigo-400 via-purple-500 to-pink-500 px-10 py-3 text-sm font-semibold uppercase tracking-[0.35em] text-white shadow-lg shadow-indigo-500/20 transition hover:-translate-y-0.5"
            disabled={status.state === 'loading'}
          >
            {status.state === 'loading' ? 'Sending...' : 'Submit'}
          </motion.button>

          {status.state !== 'idle' && (
            <p
              className={`text-center text-sm font-semibold ${
                status.state === 'success'
                  ? 'text-emerald-300'
                  : status.state === 'error'
                  ? 'text-red-300'
                  : 'text-indigo-200'
              }`}
            >
              {status.message}
            </p>
          )}
          </motion.form>
        </div>
      </div>
    </section>
  )
}
