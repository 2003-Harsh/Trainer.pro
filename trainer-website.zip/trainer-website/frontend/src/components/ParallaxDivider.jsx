import React from 'react'

export default function ParallaxDivider({ background }) {
  const layers = background
    ? `linear-gradient(120deg, rgba(99, 102, 241, 0.65), rgba(236, 72, 153, 0.55)), url(${background})`
    : 'linear-gradient(120deg, rgba(99, 102, 241, 0.65), rgba(236, 72, 153, 0.55))'

  return (
    <div
      className="parallax-layer relative h-32 w-full"
      style={{
        backgroundImage: layers,
      }}
    >
      <div className="absolute inset-0 bg-slate-900/30" />
    </div>
  )
}

