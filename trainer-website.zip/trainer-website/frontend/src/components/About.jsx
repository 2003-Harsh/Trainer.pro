import React, { useEffect, useState, useRef } from 'react'
import { motion, useInView } from 'framer-motion'

const stats = [
  { value: '150+', label: 'Institutions Trained', numeric: 150, suffix: '+' },
  { value: '25K', label: 'Learners Impacted', numeric: 25, suffix: 'K' },
  { value: '4.9/5', label: 'Average Session Rating', numeric: 4.9, suffix: '/5' },
]

function Counter({ target, suffix, duration = 2 }) {
  const [count, setCount] = useState(0)
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  useEffect(() => {
    if (!isInView) return

    let startTime = null
    const animate = (currentTime) => {
      if (!startTime) startTime = currentTime
      const progress = Math.min((currentTime - startTime) / (duration * 1000), 1)

      // Easing function for smooth animation
      const easeOutQuart = 1 - Math.pow(1 - progress, 4)
      const current = easeOutQuart * target

      setCount(current)

      if (progress < 1) {
        requestAnimationFrame(animate)
      } else {
        setCount(target)
      }
    }

    requestAnimationFrame(animate)
  }, [isInView, target, duration])

  const formatValue = () => {
    if (suffix === 'K') {
      return `${Math.floor(count)}${suffix}`
    } else if (suffix === '/5') {
      return `${count.toFixed(1)}${suffix}`
    } else {
      return `${Math.floor(count)}${suffix}`
    }
  }

  return (
    <div ref={ref} className="text-3xl font-bold text-indigo-500">
      {formatValue()}
    </div>
  )
}

export default function About() {
  return (
    <section id="about" className="relative overflow-hidden bg-white py-24">
      <div className="absolute -top-32 -right-32 h-64 w-64 rounded-full bg-indigo-100 blur-3xl" />
      <div className="absolute -bottom-20 -left-20 h-48 w-48 rounded-full bg-purple-100 blur-3xl" />

      <div className="relative mx-auto flex max-w-6xl flex-col gap-16 px-6 lg:flex-row lg:items-center">
        <motion.div
          className="flex-1 space-y-6"
          data-aos="fade-right"
        >
          <h2 className="text-3xl font-bold text-slate-900 md:text-4xl">
            Delivering immersive learning journeys that spark lasting change
          </h2>
          <p className="text-lg text-slate-600">
            I collaborate with schools, universities, and corporates to design training programs that blend pedagogy,
            technology, and real-world experiences. From upskilling educators to empowering student leaders and corporate
            teams, every engagement is tailored to your context.
          </p>
          <p className="text-lg text-slate-600">
            My sessions are rooted in storytelling, experiential learning, and data-driven outcomes, ensuring participants
            leave energized, equipped, and ready to apply what they learn.
          </p>

          <div className="grid gap-6 pt-6 sm:grid-cols-3">
            {stats.map((item) => (
              <motion.div
                key={item.label}
                className="rounded-2xl bg-slate-50 p-6 text-center shadow-sm"
                whileHover={{ y: -8 }}
                transition={{ type: 'spring', stiffness: 200, damping: 20 }}
              >
                <Counter target={item.numeric} suffix={item.suffix} duration={2} />
                <div className="mt-2 text-sm font-semibold uppercase tracking-widest text-slate-500">
                  {item.label}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div
          className="flex-1"
          data-aos="fade-left"
        >
          <div className="rounded-3xl bg-gradient-to-br from-indigo-400 to-purple-500 p-1 shadow-2xl">
            <div className="glass-surface rounded-[26px] p-4 bg-white">
              <img
                src="/Image-Trainer.png"
                alt="Aman Srivastava - Certified Master Trainer"
                className="w-full h-auto rounded-[18px] object-contain"
              />
            </div>
            <div className="mt-6 text-center px-4">
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                Aman Srivastava – Certified Master Trainer
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Empowering professionals with 5+ years of expertise in workforce development and performance enhancement.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

