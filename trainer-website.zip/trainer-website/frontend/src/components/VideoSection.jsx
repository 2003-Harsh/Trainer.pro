import React from 'react'
import { motion } from 'framer-motion'

export default function VideoSection() {
  return (
    <section className="relative bg-slate-900 py-24 text-white">
      <div className="absolute inset-0 overflow-hidden">
        <div className="parallax-layer h-full w-full opacity-10" style={{ backgroundImage: 'linear-gradient(135deg, #6366f1 0%, #a855f7 50%, #22d3ee 100%)' }} />
      </div>

      <div className="relative mx-auto flex max-w-5xl flex-col items-center gap-12 px-6 lg:flex-row">
        <motion.div
          className="w-full flex-1"
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
        >
          <div className="aspect-video overflow-hidden rounded-3xl border border-white/10 shadow-2xl">
            <video
              className="h-full w-full object-cover"
              controls
              poster="/placeholder-hero.svg"
              onError={(e) => console.error('Video error:', e)}
            >
              <source src="/hero-video.mp4.mp4" type="video/mp4" />
              <source src="/placeholder-hero.svg" type="image/svg+xml" />
              Your browser does not support the video tag.
            </video>
          </div>
          <p className="mt-4 text-sm text-slate-300">
          Experience powerful, interactive learning that inspires growth and lasting impact
          </p>
        </motion.div>

        <motion.div
          className="flex-1 space-y-6"
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
        >
          <p className="text-lg font-extrabold uppercase tracking-[0.2em] text-teal-300">Experience</p>
          <h2 className="text-3xl font-semibold md:text-4xl">
            See a glimpse of the immersive experiences designed for your teams
          </h2>
          <p className="text-lg text-slate-300">
            Each session combines dynamic facilitation, interactive tools, and actionable frameworks. Showcase your best work here - recorded workshops, keynote highlights, or learner stories.
          </p>
          <ul className="space-y-3 text-sm font-semibold tracking-wide text-slate-300">
            <li className="flex gap-3">
              <span className="mt-1 h-2.5 w-2.5 rounded-full bg-indigo-400" />
              Add timestamps, captions, or testimonials in your final version.
            </li>
            <li className="flex gap-3">
              <span className="mt-1 h-2.5 w-2.5 rounded-full bg-purple-400" />
              Embed video from YouTube, Vimeo, or host locally - Vite supports both.
            </li>
          </ul>
        </motion.div>
      </div>
    </section>
  )
}

