import React from 'react'
import { motion } from 'framer-motion'

const headline = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6 } },
}

const buttonGroup = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { delay: 0.35, duration: 0.5 } },
}

export default function Hero() {
  return (
    <section id="home" className="relative h-screen flex items-center overflow-hidden">
      <div className="absolute inset-0">
        <video
          className="h-full w-full object-cover"
          autoPlay
          muted
          loop
          playsInline
          poster="/placeholder-hero.svg"
        >
          <source src="/hero-video.mp4.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/70 via-slate-900/60 to-slate-900/80 mix-blend-multiply" />
      </div>

      <div className="relative z-10 mx-auto flex max-w-5xl flex-col items-center px-6 text-center text-white" data-aos="fade-up">
        <motion.span
          className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/40 px-4 py-2 text-xs font-semibold uppercase tracking-[0.35em] text-white/80 backdrop-blur-sm"
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.15, duration: 0.45 }}
        >
          Trusted Trainer | 5+ Years
        </motion.span>

        <motion.h1
          variants={headline}
          initial="hidden"
          animate="show"
          className="text-4xl font-bold leading-tight md:text-6xl md:leading-tight"
        >
          Empowering Schools, Universities, and Corporates with Purposeful Learning
        </motion.h1>

        <motion.p
          className="mt-6 max-w-2xl text-lg text-white/85 md:text-xl"
          variants={headline}
          initial="hidden"
          animate="show"
          transition={{ delay: 0.2 }}
        >
          Tailored workshops, immersive programs, and measurable impact that elevate educators, students, and teams to their next milestone.
        </motion.p>

        <motion.div
          className="mt-10 flex flex-col gap-4 sm:flex-row sm:gap-6"
          variants={buttonGroup}
          initial="hidden"
          animate="show"
        >
          <a
            href="#contact"
            className="rounded-full bg-gradient-to-r from-indigo-400 via-indigo-500 to-purple-500 px-8 py-3 text-sm font-semibold uppercase tracking-wider shadow-lg shadow-indigo-500/20 transition-transform hover:-translate-y-0.5 hover:shadow-xl"
          >
            Book a Discovery Call
          </a>
          <a
            href="#programs"
            className="rounded-full border border-white/60 px-8 py-3 text-sm font-semibold uppercase tracking-wider text-white transition hover:border-white hover:bg-white/10"
          >
            Explore Programs
          </a>
        </motion.div>
      </div>
    </section>
  )
}
