import React, { useEffect } from 'react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import About from './components/About'
import Programs from './components/Programs'
import ParallaxDivider from './components/ParallaxDivider'
import VideoSection from './components/VideoSection'
import Testimonials from './components/Testimonials'
import Contact from './components/Contact'
import AOS from 'aos'

export default function App() {
  useEffect(() => {
    AOS.refresh()
  }, [])

  return (
    <div className="font-sans">
      <Navbar />
      <Hero />
      <main>
        <About />
        <ParallaxDivider />
        <Programs />
        <ParallaxDivider />
        <VideoSection />
        <Testimonials />
        <Contact />
      </main>
      <footer className="bg-slate-950 py-10 text-center text-sm text-slate-400">
        &copy; {new Date().getFullYear()} TrainerPro. All rights reserved.
      </footer>
    </div>
  )
}
