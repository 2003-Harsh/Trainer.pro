const express = require('express')
const router = express.Router()

const messageStore = []

router.post('/', async (req, res) => {
  const { name, email, message } = req.body

  if (!name || !email || !message) {
    return res.status(400).json({ ok: false, message: 'Please provide your name, email, and message.' })
  }

  const entry = {
    name,
    email,
    message,
    receivedAt: new Date().toISOString(),
  }

  messageStore.push(entry)
  console.log('Contact submission stored in memory', entry)

  res.status(201).json({
    ok: true,
    message: 'Thanks! I will get back to you soon.',
  })
})

module.exports = router

