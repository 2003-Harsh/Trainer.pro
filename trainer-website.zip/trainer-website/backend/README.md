Backend (Express) for Trainer Website
=====================================

Endpoints
---------
- `POST /api/contact` — accepts JSON `{ name, email, message }` and keeps it in an in-memory list (clears on restart)
- `GET /api/health` — lightweight health check

Setup
-----
1. `cd backend`
2. `npm install`
3. Copy `.env.example` to `.env` (optional) and tweak the `PORT` if needed
4. `npm run dev` (or `npm start` for production)

Notes
-----
- Submissions are kept in process memory for quick prototypes. Hook up a database or email service before production use.
- When deploying a combined build, ensure the frontend `dist` folder is available so Express can serve static assets.
